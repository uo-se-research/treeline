/*
 *              Async Open Source - Brasil.      http://async.com.br
 *
 * wf: a very simple word frequency counter
 *
 * License: GPL . (See COPYING file)
 *
 * Marcelo Corbani de Barros
 * marcelo@async.com.br 
 * http://async.com.br/~marcelo
 *
 * 2000-29-09 - created.
 */

#include <getopt.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <getopt.h>
#include <libintl.h> /* Config FIXME - Platform dependant feature */
#include <locale.h>
#include <ctype.h>

#include "freq.h"

#define GT(str) gettext(str)

/* Default Options */
struct opttable opt = { 0, 0, 0, 0, 0, 0, 0, NULL };

struct option long_options[] =
{
	{"sort", 0, 0, 's'},
	{"help", 0, 0, 'h'},
	{"file", 1, 0, 'f'},
	{"nocase", 0, 0, 'i'},
	{"nocount", 0, 0, 'n'},
	{"mincount", 1, 0, 'm'},
	{"minlen", 1, 0, 'l'},
	{"perword", 0, 0, 'w'},
	{0, 0, 0, 0}
};

void
usage (void) {
	fprintf(stderr, GT("Usage: wf [OPTION]... [FILE]...\n"));
	fprintf(stderr, GT("\n"));
	fprintf(stderr, GT(" -h, --help\t\tthis help\n"));
	/* fprintf(stderr, GT(" -f, --file=file\tuse file <file>\n")); */
	fprintf(stderr, GT(" -s, --sort\t\tsort output\n"));
	fprintf(stderr, GT(" -i, --case\t\tignore case\n"));
	fprintf(stderr, GT(" -n, --nocount\t\tdon't output frequency count\n"));
	fprintf(stderr, GT(" -m, --mincount\t\tminimum frequency output\n"));
	fprintf(stderr, GT(" -l, --minlen\t\tminimum fragment length\n"));
	fprintf(stderr, GT(" -w, --perword\t\toutput words tied to fragment\n"));
	fprintf(stderr, GT("\n"));
}

int
main (int argc, char *argv[])
{
	/* Option parsing */
	int c;
	int digit_optind = 0;
	int i;

	/* File */
	FILE * fp;
	char * fname;
	unsigned char *q;
	char *r;
	char fmt[128];
	char buf[1024];
	char buf_orig[1024];
	int wsize;
	int ret;

	extern FILE  *stdin;

	/* Plus */
	int wcount=0;

	/* I only want to enforce ctype uses ISO-8859-1 here. can�t I do that 
	 * without necessarily setting a _real_ location ? If I simply don�t 
	 * set a valid 8 bit char locale here, I get 7 bit ascii chars.
	 */
	setlocale(LC_CTYPE,"pt_BR");
	//setlocale(LC_CTYPE,"pt_BR.utf8");

	/*  Command line options */
	while (1)
	{
		int this_option_optind = optind ? optind : 1;
		int option_index = 0;

		if ((c = getopt_long (argc, argv, "shf:inm:wl:",
			long_options, &option_index)) == -1) break;

		switch (c)
		{
			case 'h':
				usage();
				exit(0);
				break;

			case 0:
				if (optarg)
					fprintf (stderr, " with arg %s", optarg);
				fprintf (stderr, "\n");
				break;

			case 's':
				opt.sort = 1;
				break;

			case 'f':
				opt.file = 1;
				opt.fname = optarg;
				break;

			case 'i':
				opt.nocase = 1;
				break;

			case 'n':
				opt.nocount = 1;
				break;

			case 'l':
				opt.min_length = atol(optarg);
				break;

			case 'm':
				opt.min_count = atol(optarg);
				break;

			case 'w':
				opt.per_word = 1;
				break;

			case '?':
				break;

			default:
				fprintf (stderr, "?? getopt returned character code 0%o ??\n", c);
		}
	}

	// FIXME -- missing check for '-f' cmd line option 
	if (optind != argc) 
	{
		fname = argv[optind];	

		if ((fp = fopen(fname,"r")) == NULL) {
			fprintf(stderr, "Cannot read file: \"%s\"\n\n",fname);
			exit(1);
		}
	}
	else // No file was supplied, so we get stdin
		fp = stdin;
		
	/* Split input in words */
	sprintf(fmt, "%%%d[A-Za-z%s]%%n", sizeof(buf)-1, wfsc_table);
	while (1)
	{
		if (fgets(buf_orig, sizeof(buf_orig) - 1, fp) == NULL) break;
	        if ((q = strchr(buf_orig, '\n')) != NULL)
       		     *q = '\0';
		q = buf_orig;

		while (1) {
			if (wf_isalpha(*q)) {
				if ((ret = sscanf(q, fmt, buf, &c))) {
					/* Check for case sensitive option */
					if (opt.nocase)
						str_tolower(buf);

					if (c >= opt.min_length) {
						if (addword(buf_orig, buf))
							wcount++;
					}

					q += c;
				} else {
					q++;
				}
			} else if (*q == '\0') {
				break;
			} else {
				q++;
			}
		}
	}

	/* Output result with choosen ordering option */
	if (opt.sort)
		wordsort(wcount);
	else
		worddump();

	fprintf(stderr, "Total words: %d\n",wcount);

	exit(0);
}
