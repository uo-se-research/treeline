/*
 *              Async Open Source - Brasil.      http://async.com.br
 *
 * wf: a very simple word frequency counter
 *
 * License: GPL . (See COPYING file)
 *
 * Marcelo Corbani de Barros
 * marcelo@async.com.br 
 * http://async.com.br/~marcelo
 *
 * 2000-29-09 - created.
 */


#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include "freq.h"

/* 
 * Since wf is not managing character sets using somehting like libiconv to an
 * internal representation (it assumes ISO-LATIN-1) it is necessary to handle
 * this 8 bits representation robustly. I did not manage to get isalpha to
 * behave as to consider accent chars using setLocale, so I am handling it the
 * hard way.
 */
int
wf_isalpha(unsigned char c)
{
	return wf_alphamap[c];
}

int
wf_tolower(unsigned char c)
{
	return wf_lowermap[c];
}

void
str_tolower(char *str)
{
	int i;

	for (i=0; i < strlen(str); i++) {
		str[i] = wf_tolower(str[i]);
		/* str[i] = tolower(str[i]); */
	}
}

unsigned int 
hash (char *str)
{
	unsigned int h;
	unsigned char *p;

	h = 0;
	for (p = (unsigned char *) str; *p != '\0'; p++)
		h = MULTIPLIER * h + *p;

	return h % NHASH;
}

Wordsource *
addword_source(Wordsource *w, char *orig)
{
	char *q;
	Wordsource *wn;

	wn = w;

	for (; wn != NULL; wn = wn->next)
	{
		if (strcmp(orig, wn->orig) == 0) {
			return w;
		}
	}

	wn = malloc(sizeof(*wn));
	wn->orig = malloc(strlen(orig)+1);
	strcpy(wn->orig, orig);
	wn->next = w;

	return wn;
}

int
addword (char *orig, char *name)
{
	int h;
	char * text;
	Wordlist *w;

	h = hash(name);
	for (w = wordhash[h]; w != NULL; w = w->next)
	{
		if (strcmp(name, w->text) == 0) {
			w->count++;
			w->source = opt.per_word ? addword_source(w->source, orig): NULL;
			return 0;
		}
	}
	
	w = malloc(sizeof(*w));
	w->text = malloc(strlen(name)+1);
	strcpy(w->text, name);
	w->count = 1;
	w->source = opt.per_word ? addword_source(NULL, orig) : NULL;
	w->next = wordhash[h];
	wordhash[h] = w;

	return 1;
}

int
cmpword(const void *w1,const void *w2)
{
	return ( (*(Wordlist **)w2)->count - (*(Wordlist **)w1)->count );
}

void
worddump_source(Wordsource *w)
{
	for (; w != NULL; w = w->next)
		fprintf (stdout, "\n\t%s ", w->orig);

	return;
}

void
worddump (void) 
{
	Wordlist *w;
	int	h;

	for (h = 0; h < NHASH; h++)
		for (w = wordhash[h]; w != NULL; w = w->next) {
			do_output(w);
		}
	return;
}

void
wordsort (int amount)
{
	Wordlist *w, *r;
	Wordlist **u,**t;
	int	h;
	int i=0;
	
	u = (Wordlist **)malloc(sizeof(Wordlist *)*(amount +1));
	t = u;

	for (h = 0; h < NHASH; h++)
		for (w = wordhash[h]; w != NULL; w = w->next)
		{
			*u = w;
			u++;
		}	

	qsort(t,amount,sizeof(Wordlist *),cmpword);

	for (h = 0; h < amount; h++)
	{
		r = t[h];
		do_output(r);
	}

	return;
}

void
do_output (Wordlist *w)
{
	if (w->count < opt.min_count) 
		return;
	else if (opt.nocount)
		fprintf (stdout, "%s\t", w->text);
	else
		fprintf (stdout, "%5d\t%s",w->count, w->text);

	if (opt.per_word) worddump_source(w->source);
	fprintf (stdout, "\n");

	return;
}

